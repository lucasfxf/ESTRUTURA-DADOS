import java.util.Iterator; // 
import java.util.NoSuchElementException; // 

public class PilhaEncadeada<T> implements Iterable<T> // 
{
    private No<T> topo;
    private int size;

    public PilhaEncadeada() {
        this.topo = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return this.topo == null;
    }

    public boolean push(T dado) {
        No<T> novoNo = new No<>(dado);
        novoNo.setProximo(this.topo);
        this.topo = novoNo;
        this.size++;
        return true;
    }

    public T pop(){
        if(!isEmpty()){
            T removido = this.topo.getDado();
            this.topo = this.topo.getProximo();
            this.size--;
            return removido;
        }
        return null;
    }

    @Override
    public String toString(){
        StringBuilder pilha = new StringBuilder("*** Topo ***\n");
        No<T> noAtual = this.topo;

        while (noAtual != null) {
            pilha.append(noAtual.getDado() + "\n");
            noAtual = noAtual.getProximo();
        }

        pilha.append("__________\n");
        return pilha.toString();
    }

    // 🔽 MÉTODO NECESSÁRIO PRO FOREACH
    @Override
    public Iterator<T> iterator() { //
        return new PilhaIterator(); //
    }

    // 🔽 CLASSE INTERNA DO ITERATOR
    private class PilhaIterator implements Iterator<T> { //

        private No<T> atual = topo; //

        @Override
        public boolean hasNext() { //
            return atual != null; //
        }

        @Override
        public T next() { //
            if (!hasNext()) { //
                throw new NoSuchElementException(); //
            }
            T valor = atual.getDado(); //
            atual = atual.getProximo(); //
            return valor; //
        }
    }
}