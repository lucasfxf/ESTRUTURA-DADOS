public class No<T> {
    private T dado;
    private No<T> proximo;

    public No(T novodado) {
        this.dado = novodado;
        this.proximo = null;
    }

    public T getDado() {
        return dado;
    }

    public No<T> getProximo() {
        return proximo;
    }

    public void setProximo(No<T> proximo) {
        this.proximo = proximo;
    }
}
